package com.test.todolist.repositories;

import com.test.todolist.entities.TaskLinks;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TaskLinksRepository extends CrudRepository<TaskLinks, Long> {
    @Query("SELECT childId FROM TaskLinks")
    List<Long> listChildId();
    @Query("SELECT parentId FROM TaskLinks")
    List<Long> listParentId();

    //Тут стоит переименновать!

    @Query("SELECT childId FROM TaskLinks WHERE parentId = ?1")
    List<Long> getAllByChildId(Long parentId);
    @Query("SELECT parentId FROM TaskLinks WHERE childId = ?1")
    List<Long> getAllByParentId(Long childId);
}