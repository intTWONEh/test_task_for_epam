package com.test.todolist.services;

import com.test.todolist.entities.Task;
import com.test.todolist.entities.TaskLinks;
import com.test.todolist.repositories.TaskLinksRepository;
import com.test.todolist.repositories.TaskRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class TaskService {
    private final TaskRepository taskRepository;
    private final TaskLinksRepository taskLinksRepository;
    private final Scanner Input = new Scanner(System.in);

    public TaskService(TaskRepository taskRepository, TaskLinksRepository taskLinksRepository) {
        this.taskRepository = taskRepository;
        this.taskLinksRepository = taskLinksRepository;
    }

    //•  Создание объекта ToDo;
    public void createTask(Long id){
        System.out.println("Введите свойства новой задачи");
        Task task = new Task();
        task.setDescription(requestDescription());
        task.setTaskStartTime(LocalDateTime.now());
        task.setTaskEndTime(requestDateEnd());
        task.setStatus(false);
        task.setUserId(id);
        task.setMessageSend(false);
        taskRepository.save(task);
    }

    //•  создание дочернего объекта ToDo (Уровень вложенности неограничен);
    public void linkTask(Long id){
        Long parentTaskId;
        Long childTaskId;

        do{
            parentTaskId = _getIdTask("Укажите имя задачи для которой нужно сделать связь: ", id);
            childTaskId = _getIdTask("Укажите имя задачи которая будет под задачей: ", id);

            if(checkLinkTask(parentTaskId, childTaskId)){
                TaskLinks taskLinks = new TaskLinks();
                taskLinks.setParentId(parentTaskId);
                taskLinks.setChildId(childTaskId);
                taskLinksRepository.save(taskLinks);
                System.out.println("Связь создана.");
                return;
            }
        }while (true);
    }

    //•  пометка заданного ToDo как выполненное (Доступно, только если все дочерние ToDo выполнены);
    //Нужен рефакторинг
    public void checkTask(Long id){
        Long idTask = _getIdTask("Введите название выполненой задачи: ",id);
        Optional<Task> Task = taskRepository.findById(idTask);
        List<Long> listParentId = taskLinksRepository.getAllByParentId(idTask);

        if(Task.get().getStatus()){
            System.out.println("Задача уже выполнена");
            return;
        }

        if(!listParentId.isEmpty()){
            AtomicReference<Boolean> tmpStatus = new AtomicReference<>(true);

            listParentId.forEach(
                    (parentTaskId) -> {
                        Optional<Task> tmpTask = taskRepository.findById(parentTaskId);
                        if(!tmpTask.get().getStatus()) {
                            System.out.println("Есть не выполненая задача: " + tmpTask.get().getDescription());
                            tmpStatus.set(false);
                            return;
                        }
                    }
            );

            if(tmpStatus.get()) {
                Task.get().setStatus(true);
                taskRepository.save(Task.get());
                System.out.println("Задача отмечена");
            }
        } else {
            Task.get().setStatus(true);
            taskRepository.save(Task.get());
            System.out.println("Задача отмечена");
        }
    }

    //•  получение всех невыполненных ToDo (с сортировками по полям);
    //Можно дополнить фильтр по своему запросу <, >, =
    public void showNotEndTask(Long id){
       List<Task> listTask = taskRepository.getOutstandingTask(id);
       List<Comparator<Task>> comparatorList = List.of(
               (id_1, id_2) -> id_1.getId().compareTo(id_2.getId()),
               (id_1, id_2) -> id_1.getMessageSend().compareTo(id_2.getMessageSend()),
               (id_1, id_2) -> id_1.getTaskStartTime().compareTo(id_2.getTaskStartTime()),
               (id_1, id_2) -> id_1.getTaskEndTime().compareTo(id_2.getTaskEndTime())
       );

        System.out.println(
                "По какому полю сортируем: "+
                 "\n[id - 0], [Отправлено ли сообщение - 1], [Время начала задачи - 2], [Время завершения задачи - 3]"
        );

        String action = Input.next().toLowerCase(Locale.ROOT);

        System.out.println(
                "Какой порядок: "+
                 "\n[по возрастанию - 0], [по убыванию - 1]"
        );

        action += Input.next().toLowerCase(Locale.ROOT);

        switch (action) {
            case "00": listTask.sort(comparatorList.get(0)); break;
            case "01": listTask.sort(comparatorList.get(0).reversed()); break;
            case "10": listTask.sort(comparatorList.get(1)); break;
            case "11": listTask.sort(comparatorList.get(1).reversed()); break;
            case "20": listTask.sort(comparatorList.get(2)); break;
            case "21": listTask.sort(comparatorList.get(2).reversed()); break;
            case "30": listTask.sort(comparatorList.get(3)); break;
            case "31": listTask.sort(comparatorList.get(3).reversed()); break;
            default:
                System.out.println("Не вверный ввод или выход"); return;
        }

        listTask.forEach(
                task -> {showInfoTask(task);
                System.out.println();
        }
        );
    }

    public void deleteTask(Long id){
        taskRepository.deleteById(_getIdTask("Введите название удаляемой задачи: ",id));
    }

    public void updateTask(Long id){
        //Изменяем имя, время окончания
        System.out.println("Пока не реализовано....");
    }
    private Boolean checkLinkTask(Long parentTaskId, Long childTaskId){
        if(parentTaskId.equals(childTaskId)){
            System.out.println("Нельзя указать основную задачу как под задачу!");
            return false;
        }

        List<Long> listParentTask = taskLinksRepository.listParentId();
        List<Long>  listChildTask = taskLinksRepository.listChildId();

        if(listParentTask.contains(parentTaskId) && listChildTask.contains(childTaskId)){
            System.out.println("Связь уже создана.");
            return false;
        }

        if(listParentTask.contains(childTaskId) && listChildTask.contains(parentTaskId)){
            System.out.println("Создание циклической связи!");
            return false;
        }
        return true;
    }
    //•  при выполнении недопустимой операции (Отметка о готовности несуществующего ToDo), возвращать соответствующее сообщение;
    private Long getIdTask(Long id){
        List<Task> Task;
        String TaskDesc = Input.next();
        Task = taskRepository.findByDescriptionAndUserId(TaskDesc, id);

        if (Task.isEmpty()) {
            System.out.println("Нет такой задачи.");
            return 0L;
        }
        if (Task.size() > 1) {
            System.out.println("У вас несколько задач с таким именем:");
            Task.forEach(this::showInfoTask);
            System.out.println("\nуточните задачу (выбирите id): ");
            return Input.nextLong();
        } else {
            return Task.get(0).getId();
        }
    }
    private Long _getIdTask(String text, Long id){
        Long tmp;
        do {
            System.out.print(text);
            tmp = getIdTask(id);
            if (!tmp.equals(0L)) return tmp;
        } while (true);
    }
    private String requestDescription(){
        do {
            System.out.println("Введите описание:");
            String Description = Input.next();

            if (Description.length() <= 255){
                return Description;
            } else {
                System.out.println("Слишком длинное описание! Максимум 255 символов.");
            }
        } while (true);
    }
    private LocalDateTime requestDateEnd(){
        LocalDateTime DateEnd;
        int year, month, dayOfMonth, hour, minute;

        do {
            try {
                System.out.print("Год: "); year = Input.nextInt();
                System.out.print("Месяц: "); month = Input.nextInt();
                System.out.print("День месяца: "); dayOfMonth = Input.nextInt();
                System.out.print("Часы: "); hour = Input.nextInt();
                System.out.print("Минуты: "); minute = Input.nextInt();
            } catch (Exception e){
                System.out.println("Неверный ввод! Необходимо вводить числа.");
                Input.nextLine();
                continue;
            }

            try {
                DateEnd = LocalDateTime.of(year, month, dayOfMonth, hour, minute);
            } catch (Exception e) {
                System.out.println("Неверный ввод! Введены не коректные числа.");
                continue;
            }

            if(LocalDateTime.now().isAfter(DateEnd)){
                System.out.println("Вы ввели некорректную или старую дату!");
                continue;
            }

            return DateEnd;
        }while (true);
    }
    private Long timeToTaskCompletion(LocalDateTime Start, LocalDateTime End){
        return ChronoUnit.MINUTES.between(Start, End);
    }

    //Можно чуть улучшить вывод подпись задача просрочена + рефакторинг
    private void showInfoTask(Task task){
        System.out.println(
                "\nId задачи: " + task.getId() +
                "\nОписание задачи: " + task.getDescription() +
                "\nДата создания задачи: " + task.getTaskStartTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) +
                "\nДата завершеня задачи: " + task.getTaskEndTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) +
                "\nДано времени на задачу в минутах: " + timeToTaskCompletion(task.getTaskStartTime(), task.getTaskEndTime()) +
                "\nОсталось времени до завершения задачи в минутах: " + timeToTaskCompletion(LocalDateTime.now(), task.getTaskEndTime()) +
                "\nСостояние задачи: " + task.getStatus() +
                "\nБыло ли отправлено сообщение: " + task.getMessageSend()
        );

        System.out.print("Зависимые задачи: ");
        List<Long> listId = taskLinksRepository.getAllByChildId(task.getId());
        if(listId.isEmpty()) System.out.print("отсутствуют");
        else listId.forEach(id -> System.out.print(taskRepository.findById(id).get().getDescription() + " "));

        System.out.print("\nЗадача зависит от задач: ");
        listId = taskLinksRepository.getAllByParentId(task.getId());
        if(listId.isEmpty()) System.out.print("отсутствуют\n");
        else listId.forEach(id -> System.out.print(taskRepository.findById(id).get().getDescription() + " "));
    }
}
